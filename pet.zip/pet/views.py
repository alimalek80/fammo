from django.shortcuts import render, redirect, get_object_or_404
from .forms import PetForm, Step1NameForm, Step2GenderForm, Step3AgeForm, Step4BreedForm, Step5FoodForm, Step6FoodFeelingForm, Step7FoodImportanceForm, Step8BodyTypeForm, Step9WeightForm, Step10ActivityLevelForm, Step11FoodAllergiesForm
from .models import Pet
from django.contrib.auth.decorators import login_required, user_passes_test
from django.http import JsonResponse
from .models import Breed, PetType, AgeCategory
from django.contrib import messages
import csv
from django.http import HttpResponse
from formtools.wizard.views import SessionWizardView


@login_required
def pet_form_view(request, pk=None):
    if pk:
        pet = get_object_or_404(Pet, pk=pk, user=request.user)
    else:
        pet = None

    # --- LIMITATION LOGIC: Only when adding a new pet ---
    if not pet:  # Only check limit when adding, not editing
        user = request.user
        if not user.is_staff:
            profile = getattr(user, 'profile', None)
            plan = getattr(profile, 'subscription_plan', None)
            if plan:
                pet_limit = plan.pet_limit() if hasattr(plan, 'pet_limit') else 1
                current_pet_count = Pet.objects.filter(user=user).count()
                if current_pet_count >= pet_limit:
                    messages.error(request, f"You can only add up to {pet_limit} pets with your current plan.")
                    return redirect('pet:my_pets')

    if request.method == 'POST':
        form = PetForm(request.POST, instance=pet)
        if form.is_valid():
            new_pet = form.save(commit=False)
            new_pet.user = request.user
            new_pet.save()
            form.save_m2m()
            return redirect('pet:my_pets')  # Replace with your pets list view name
    else:
        form = PetForm(instance=pet)

    # Get PetType objects for Cat and Dog
    cat_type = PetType.objects.filter(name__iexact='Cat').first()
    dog_type = PetType.objects.filter(name__iexact='Dog').first()
    cat_ages = AgeCategory.objects.filter(pet_type=cat_type) if cat_type else []
    dog_ages = AgeCategory.objects.filter(pet_type=dog_type) if dog_type else []

    context = {
        'form': form,
        'is_edit': bool(pet),
        'cat_ages': cat_ages,
        'dog_ages': dog_ages,
    }
    return render(request, 'pet/pet_form.html', context)

def load_breeds(request):
    pet_type_id = request.GET.get('pet_type')
    breeds = Breed.objects.filter(pet_type_id=pet_type_id).order_by('name')
    return JsonResponse(list(breeds.values('id', 'name')), safe=False)

def my_pets_view(request):
    if not request.user.is_authenticated:
        messages.info(request, "Please log in to view your pets.")
        return redirect('login')  # Use your login URL name
    pets = request.user.pets.all()
    return render(request, 'pet/my_pets.html', {'pets': pets})

@login_required
def delete_pet_view(request, pk):
    pet = get_object_or_404(Pet, pk=pk, user=request.user)
    
    if request.method == "POST":
        pet.delete()
        return redirect('pet:my_pets')
    
    # If somehow accessed via GET (not expected), redirect safely
    return redirect('pet:my_pets')

@login_required
def pet_detail_view(request, pk):
    pet = get_object_or_404(Pet, pk=pk, user=request.user)
    return render(request, 'pet/pet_detail.html', {'pet': pet})

@user_passes_test(lambda u: u.is_staff or u.is_superuser)
def export_pets_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="pets.csv"'

    writer = csv.writer(response)
    # Write header (all fields)
    writer.writerow([
        'ID', 'Name', 'User Email', 'Type', 'Gender', 'Neutered', 'Age Category',
        'Age (years)', 'Age (months)', 'Age (weeks)', 'Breed', 'Food Types',
        'Food Feeling', 'Food Importance', 'Body Type', 'Weight', 'Activity Level',
        'Food Allergies', 'Other Food Allergy', 'Health Issues', 'Treat Frequency'
    ])
    # Write data
    for pet in Pet.objects.select_related(
        'user', 'pet_type', 'gender', 'age_category', 'breed', 'food_feeling',
        'food_importance', 'body_type', 'activity_level', 'treat_frequency'
    ).prefetch_related('food_types', 'food_allergies', 'health_issues').all():
        writer.writerow([
            pet.id,
            pet.name,
            pet.user.email,
            pet.pet_type.name if pet.pet_type else '',
            pet.gender.name if pet.gender else '',
            'Yes' if pet.neutered else 'No',
            pet.age_category.name if pet.age_category else '',
            pet.age_years or '',
            pet.age_months or '',
            pet.age_weeks or '',
            pet.breed.name if pet.breed else '',
            ', '.join([ft.name for ft in pet.food_types.all()]),
            pet.food_feeling.name if pet.food_feeling else '',
            pet.food_importance.name if pet.food_importance else '',
            pet.body_type.name if pet.body_type else '',
            pet.weight or '',
            pet.activity_level.name if pet.activity_level else '',
            ', '.join([fa.name for fa in pet.food_allergies.all()]),
            pet.food_allergy_other or '',
            ', '.join([hi.name for hi in pet.health_issues.all()]),
            pet.treat_frequency.name if pet.treat_frequency else '',
        ])
    return response


# ============================================================================
# NEW WIZARD IMPLEMENTATION USING SESSIONWIZARDVIEW (Step by step)
# ============================================================================

# Start with Step 1, Step 2, Step 3, Step 4, Step 5, and Step 6
FORMS = [
    ("step1", Step1NameForm),
    ("step2", Step2GenderForm),
    ("step3", Step3AgeForm),
    ("step4", Step4BreedForm),
    ("step5", Step5FoodForm),
    ("step6", Step6FoodFeelingForm),
    ("step7", Step7FoodImportanceForm),
    ("step8", Step8BodyTypeForm),
    ("step9", Step9WeightForm),
    ("step10", Step10ActivityLevelForm),
    ("step11", Step11FoodAllergiesForm),
]

class PetWizard(SessionWizardView):
    form_list = dict(FORMS)
    template_name = "pet/wizard_step.html"
    
    def get_form_kwargs(self, step=None):
        """Pass wizard instance to forms that need it"""
        kwargs = super().get_form_kwargs(step)
        if step in ['step2', 'step3', 'step4', 'step5', 'step6', 'step7', 'step8', 'step9', 'step10', 'step11']:  # Forms that need wizard instance
            kwargs['wizard'] = self
        return kwargs
    
    def get_form(self, step=None, data=None, files=None):
        """Handle invalid choice issues when user changes pet type and navigates back"""
        
        # Handle step3 age_category invalid choice issue
        if step == 'step3' and data:
            # Get current pet type from step1
            step1_data = self.get_cleaned_data_for_step('step1') or {}
            current_pet_type = step1_data.get('pet_type')
            
            if current_pet_type:
                # Check if the age_category in the form data is valid for current pet_type
                age_category_id = data.get('step3-age_category')
                if age_category_id:
                    try:
                        from .models import AgeCategory
                        age_category = AgeCategory.objects.get(pk=age_category_id)
                        if age_category.pet_type != current_pet_type:
                            # Remove invalid age category from form data
                            data = data.copy()
                            data.pop('step3-age_category', None)
                            # Also clear related age fields
                            data.pop('step3-age_years', None) 
                            data.pop('step3-age_months', None)
                            data.pop('step3-age_weeks', None)
                    except (AgeCategory.DoesNotExist, ValueError):
                        # Invalid ID, remove it
                        data = data.copy()
                        data.pop('step3-age_category', None)
                        data.pop('step3-age_years', None)
                        data.pop('step3-age_months', None) 
                        data.pop('step3-age_weeks', None)
        
        # Handle step4 breed invalid choice issue
        if step == 'step4' and data:
            # Get current pet type from step1
            step1_data = self.get_cleaned_data_for_step('step1') or {}
            current_pet_type = step1_data.get('pet_type')
            
            if current_pet_type:
                # Check if the breed in the form data is valid for current pet_type
                breed_id = data.get('step4-breed')
                if breed_id:
                    try:
                        from .models import Breed
                        breed = Breed.objects.get(pk=breed_id)
                        if breed.pet_type != current_pet_type:
                            # Remove invalid breed from form data
                            data = data.copy()
                            data.pop('step4-breed', None)
                            # Don't clear unknown_breed as user might want to keep that selection
                    except (Breed.DoesNotExist, ValueError):
                        # Invalid ID, remove it
                        data = data.copy()
                        data.pop('step4-breed', None)
        
        return super().get_form(step, data, files)
    
    def get_context_data(self, form, **kwargs):
        context = super().get_context_data(form=form, **kwargs)
        current_step = int(self.steps.current.replace('step', ''))
        total_steps = len(self.form_list)
        
        # Calculate progress: 0% for step 1, then incremental progress
        # This gives better UX: Step 1 = 0%, Step 2 = 50%, completion = 100%
        if current_step == 1:
            progress_percent = 0
        else:
            progress_percent = int(((current_step - 1) / total_steps) * 100)
        
        context.update({
            'step_number': current_step,
            'step_total': total_steps,
            'progress_percent': progress_percent,
        })
        return context
    
    def done(self, form_list, **kwargs):
        """Called when all forms are valid"""
        # Collect data from all forms
        form_data = {}
        for form in form_list:
            form_data.update(form.cleaned_data)
        
        # Create the pet with data from all eleven steps
        pet = Pet(user=self.request.user)
        pet.name = form_data.get('name')
        pet.pet_type = form_data.get('pet_type')
        pet.gender = form_data.get('gender')
        pet.neutered = form_data.get('neutered')
        pet.age_category = form_data.get('age_category')
        pet.age_years = form_data.get('age_years')
        pet.age_months = form_data.get('age_months')
        pet.age_weeks = form_data.get('age_weeks')
        pet.breed = form_data.get('breed')
        pet.unknown_breed = form_data.get('unknown_breed')
        pet.food_feeling = form_data.get('food_feeling')
        pet.food_importance = form_data.get('food_importance')
        pet.body_type = form_data.get('body_type')
        pet.weight = form_data.get('weight')
        pet.activity_level = form_data.get('activity_level')
        pet.food_allergy_other = form_data.get('food_allergy_other')
        pet.save()
        
        # Handle many-to-many fields after saving the pet
        food_types = form_data.get('food_types')
        if food_types:
            pet.food_types.set(food_types)
        
        food_allergies = form_data.get('food_allergies')
        if food_allergies:
            pet.food_allergies.set(food_allergies)
        
        messages.success(self.request, f"🎉 {pet.name} has been successfully added!")
        return redirect('pet:my_pets')


